// Dark Mode Toggle
document.getElementById("darkModeToggle").addEventListener("click", () => {
  document.body.classList.toggle("dark-mode");
});

// Event Search
document.getElementById("eventSearch").addEventListener("keyup", function () {
  let query = this.value.toLowerCase();
  document.querySelectorAll(".event").forEach(event => {
    let title = event.dataset.title.toLowerCase();
    event.style.display = title.includes(query) ? "block" : "none";
  });
});

// Join Club Buttons
document.querySelectorAll(".join-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    btn.textContent = "Joined ✅";
    btn.disabled = true;
    alert("You have joined this club!");
  });
});
